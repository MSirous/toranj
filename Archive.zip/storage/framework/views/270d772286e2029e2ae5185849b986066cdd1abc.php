<?php $__env->startSection('navbar'); ?>

    <?php $__env->stopSection(); ?>


<?php echo $__env->make('styles.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>