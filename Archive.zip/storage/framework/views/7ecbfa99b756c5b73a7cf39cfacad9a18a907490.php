<?php $__env->startSection('car'); ?>
<section class="content">

      <!-- SELECT2 EXAMPLE -->
      <strong>
         <h3>
           ویرایش خودرو 
         </h3> 
        </strong>
      <div class="box box-default">

        <div class="box-header with-border">
        
        <?php echo Form::model($cars, ['files'=> true ,'route'=>['cars.update', $cars->id] , 'method'=> 'PATCH']); ?>

          <?php echo $__env->make("cars.form", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         
        <?php echo Form::close(); ?>

        <!-- /.box-body -->
        </div>


    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>