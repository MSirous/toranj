<?php $__env->startSection('car'); ?>

<div class="box box-primary">
  <div class="box-header with-border">
    <h3 class="box-title">خودرو</h3>
    <div class="box-tools pull-right">
      <div class="has-feedback">
      <form action="<?php echo e(route('cars.index')); ?> " method="">
        <input type="text" name="term" value="<?php echo e(Request::get('term')); ?>" class="form-control input-sm" placeholder="Search Mail">
        <span class="glyphicon glyphicon-search form-control-feedback"></span>
      </form>
        
      </div>
    </div>
    <!-- /.box-tools -->
  </div>
  <!-- /.box-header -->
  <div class="box-body no-padding">
    <div class="mailbox-controls">
      تست
      <!-- /.pull-right -->
    </div>
    <div class="table-responsive mailbox-messages">
      <table class="table table-hover table-striped">
        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <tbody>
          <tr>
            <td >
              <a href="">
                <?php $photo = ! is_null($car->photo) ? $car->photo : 'default.png' ?>
                <?php echo Html::image('uploads/' . $photo , $car->name, ['class' => 'media-object' , 'width' =>150 , 'height' => 100]); ?>

              </td>
            </a>
            <td class="mailbox-name"><b><a href="read-mail.html"><?php echo e($car->date_birth); ?>, <?php echo e($car->model); ?>, <?php echo e($car->company); ?> </a></td></b>
            <td class="mailbox-subject"><b><?php echo e($car->model); ?>,<?php echo e($car->company); ?></b> </br>
            </br> - <?php echo e($car->state); ?>

          </br> - <?php echo e($car->color); ?>, <?php echo e($car->remove_color); ?>, <?php echo e($car->greabox); ?>

        </br> - کارکرد <?php echo e($car->work); ?>کیلومتر
      </td>
      <td class="mailbox-attachment"></td>
      <td><?php echo e($car->price); ?>

      </td>
      <?php echo Form::open(['method'=>'DELETE', 'route'=>['cars.destroy', $car->id]]); ?>

      <td>
      <a href="<?php echo e(route('cars.edit', ['id' => $car->id ])); ?>">
       <button type="button" class="btn btn-default btn-sm"><i class="fa fa-edit">
       </i></a>
     </button>
   </td>
      </td>
        <td class="mailbox-date">
          <button onclick = "return confirm('Are You Sure?!!');" type="submit" class="btn btn-default btn-sm">
            <i class="fa fa-trash-o"></i>
          </button>
      <?php echo Form::close(); ?>

      </td>
 </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</tbody>
</table>
<!-- /.table -->
</div>
<!-- /.mail-box-messages -->
</div>
<!-- /.box-body -->
<div class="box-footer no-padding">
  <div class="mailbox-controls">
    <!-- Check all button -->
    <div class="box-footer clearfix">
      <?php echo $cars->appends( Request::query())->render(); ?> 
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>